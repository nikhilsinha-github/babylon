import 'package:flutter/material.dart';

const primaryColor = Color(0xFFf9be07);
const cancelBtnColor = Color(0xFFf53c56);